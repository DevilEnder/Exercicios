package br.unifaj.cc.poo.sistemalanchonete;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Produto_cliente extends AppCompatActivity {

    private String nomeRecuperado;
    //lanches daqui ate
    static int quantidadeCheese = 0;
    static int quantidadeBacon = 0;
    static int quantidadeCheddar = 0;
    static int quantidadeXtudo = 0;
    //aqui
    //estoque daqui ate
    static int estoqueQueijo = 0;
    static int estoqueBacon = 0;
    static int estoqueCheddar = 0;
    static int estoqueCarne = 0;
    //aqui
    //validaçao de quantos pode pedir
    static int carnecontadas = 0;
    static int baconcontados = 0;
    static int queijocontados = 0;
    static int cheddarcontados = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_produto_cliente);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Reset dos contadores
        quantidadeCheese = 0;
        quantidadeBacon = 0;
        quantidadeCheddar = 0;
        quantidadeXtudo = 0;
        carnecontadas = 0;
        baconcontados = 0;
        queijocontados = 0;
        cheddarcontados = 0;
        nomeRecuperado = getIntent().getStringExtra("nome");
        mostrar();
    }

    public void pedido(View V){
        AdmPedidos.nomeCliente = nomeRecuperado;
        AdmPedidos.cheese = String.valueOf(quantidadeCheese);
        AdmPedidos.bacon = String.valueOf(quantidadeBacon);
        AdmPedidos.xtudo = String.valueOf(quantidadeXtudo);
        AdmPedidos.cheddar = String.valueOf(quantidadeCheddar);

        if(quantidadeCheese == 0 && quantidadeBacon == 0 && quantidadeCheddar == 0 && quantidadeXtudo == 0){
            Toast.makeText(this, "Nenhum produto selecionado", Toast.LENGTH_SHORT).show();
            return;
        }else{
            Intent i = new Intent(this, Tempo_Produto.class);
            startActivity(i);
        }

    }
    public void total(){
        TextView total = findViewById(R.id.produto_total_view);
        double totalpedido = quantidadeCheese *15.99 + quantidadeBacon *18.99 + quantidadeCheddar *19.99 + quantidadeXtudo *21.99;
        total.setText(String.format("R$ %.2f", totalpedido));
        AdmPedidos.total = String.format("R$ %.2f", totalpedido);
    }

    public void adicionarCheese(View v){
        if(estoqueQueijo > 0 && estoqueCarne > 0){
            if(queijocontados < estoqueQueijo && carnecontadas < estoqueCarne){
                quantidadeCheese++;
                queijocontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairCheese(View v){
        if(quantidadeCheese > 0){
            quantidadeCheese--;
            carnecontadas--;
            queijocontados--;
        }
        mostrar();
    }
    public void adicionarBacon(View v){
        if(estoqueBacon > 0 && estoqueCarne > 0){
            if(baconcontados < estoqueBacon && carnecontadas < estoqueCarne){
                quantidadeBacon++;
                baconcontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairBacon(View v){
        if(quantidadeBacon > 0){
            quantidadeBacon--;
            carnecontadas--;
            baconcontados--;
        }
        mostrar();
    }
    public void adicionarCheddar(View v){
        if(estoqueCheddar > 0 && estoqueCarne >0){
            if(cheddarcontados < estoqueCheddar && carnecontadas < estoqueCarne){
                quantidadeCheddar++;
                cheddarcontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairCheddar(View v){
        if(quantidadeCheddar > 0){
            quantidadeCheddar--;
            carnecontadas--;
            cheddarcontados--;
        }
        mostrar();
    }
    public void adicionarXtudo(View v){
        if(estoqueBacon >0 && estoqueCheddar >0 && estoqueQueijo >0 && estoqueCarne >0){
            if(baconcontados < estoqueBacon && queijocontados < estoqueQueijo && cheddarcontados < estoqueCheddar && carnecontadas < estoqueCarne){
                quantidadeXtudo++;
                baconcontados++;
                cheddarcontados++;
                queijocontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairXtudo(View v){
        if(quantidadeXtudo > 0){
            quantidadeXtudo--;
            baconcontados--;
            cheddarcontados--;
            queijocontados--;
            carnecontadas--;
        }
        mostrar();
    }
    public void mostrar(){
        TextView xtudoV = findViewById(R.id.produto_xtudo_view);
        TextView cheeseV = findViewById(R.id.produto_cheese_view);
        TextView baconV = findViewById(R.id.produto_bacon_view);
        TextView cheddarV = findViewById(R.id.produto_cheddar_view);

        xtudoV.setText(String.valueOf(quantidadeXtudo));
        cheeseV.setText(String.valueOf(quantidadeCheese));
        baconV.setText(String.valueOf(quantidadeBacon));
        cheddarV.setText(String.valueOf(quantidadeCheddar));

        total();
        validar();
    }
    public void validar(){
        TextView cheeseV = findViewById(R.id.produto_disponivel_cheese_view);
        TextView baconV = findViewById(R.id.produto_disponivel_bacon_view);
        TextView cheddarV = findViewById(R.id.produto_disponivel_cheddar_view);
        TextView xtudoV = findViewById(R.id.produto_disponivel_xtudo_view);

        if (queijocontados >= estoqueQueijo || carnecontadas >= estoqueCarne || estoqueQueijo == 0 || estoqueCarne == 0) {
            cheeseV.setText("(indisponivel)");
        } else {
            cheeseV.setText("(disponivel)");
        }

        if (baconcontados >= estoqueBacon || carnecontadas >= estoqueCarne || estoqueBacon == 0 || estoqueCarne == 0) {
            baconV.setText("(indisponivel)");
        } else {
            baconV.setText("(disponivel)");
        }

        if (cheddarcontados >= estoqueCheddar || carnecontadas >= estoqueCarne || estoqueCheddar == 0 || estoqueCarne == 0) {
            cheddarV.setText("(indisponivel)");
        } else {
            cheddarV.setText("(disponivel)");
        }

        if (baconcontados >= estoqueBacon || queijocontados >= estoqueQueijo || cheddarcontados >= estoqueCheddar || carnecontadas >= estoqueCarne || estoqueBacon == 0 || estoqueQueijo == 0 || estoqueCheddar == 0 || estoqueCarne == 0) {
            xtudoV.setText("(indisponivel)");
        } else {
            xtudoV.setText("(disponivel)");
        }
    }
    public void voltar(View V){
        finish();
    }
}