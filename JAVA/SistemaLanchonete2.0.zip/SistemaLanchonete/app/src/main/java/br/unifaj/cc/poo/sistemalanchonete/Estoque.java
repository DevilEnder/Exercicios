package br.unifaj.cc.poo.sistemalanchonete;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

public class Estoque extends AppCompatActivity {

    private static final String URL_BASE = "http://10.0.2.2:8080/lanchonete/ingrediente";

    private List<String> listaExibicao = new ArrayList<>();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_estoque);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        carregarIngredientes();
    }

    public void carregarIngredientes() {
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest req = new StringRequest(
                Request.Method.GET, URL_BASE,
                json -> {
                    try {
                        JSONArray array = (JSONArray) new JSONTokener(json).nextValue();
                        listaExibicao.clear();
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);
                            String nome = obj.getString("nome");
                            int qtd     = obj.getInt("quantidade");
                            listaExibicao.add(nome + "  —  " + qtd + " un.");
                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                                android.R.layout.simple_list_item_1, listaExibicao);
                        ListView lv = findViewById(R.id.estoque_lista_lv);
                        if (lv != null) lv.setAdapter(adapter);
                    } catch (Exception e) {
                        Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                erro -> Toast.makeText(this, "Servidor offline", Toast.LENGTH_SHORT).show()
        );
        queue.add(req);
    }

    public void adicionarIngrediente(View v) {
        EditText nomeET = findViewById(R.id.estoque_nome_ingrediente_et);
        EditText qtdET  = findViewById(R.id.estoque_qtd_ingrediente_et);
        EditText precoET = findViewById(R.id.estoque_preco_ingrediente_et);

        String nome = nomeET.getText().toString().trim();
        String qtdStr = qtdET.getText().toString().trim();
        String precoStr  = precoET.getText().toString().trim();

        if (nome.isEmpty() || qtdStr.isEmpty()) {
            Toast.makeText(this, "Preencha nome e quantidade", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONObject obj = new JSONObject();
            obj.put("nome", nome);
            obj.put("quantidade", Integer.parseInt(qtdStr));
            obj.put("preco", Double.parseDouble(precoStr));
            String json = obj.toString();

            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest req = new StringRequest(
                    Request.Method.POST, URL_BASE,
                    resp -> {
                        Toast.makeText(this, "Ingrediente " + nome + " adicionado!", Toast.LENGTH_SHORT).show();
                        nomeET.setText("");
                        qtdET.setText("");
                        precoET.setText("");
                        carregarIngredientes();
                    },
                    erro -> Toast.makeText(this, "Erro ao enviar", Toast.LENGTH_SHORT).show()
            ) {
                @Override public String getBodyContentType() {
                    return "application/json; charset=utf-8";
                }
                @Override public byte[] getBody() throws AuthFailureError {
                    return json.getBytes();
                }
            };
            queue.add(req);
        } catch (Exception e) {
            Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void voltar(View V){
        finish();
    }

}