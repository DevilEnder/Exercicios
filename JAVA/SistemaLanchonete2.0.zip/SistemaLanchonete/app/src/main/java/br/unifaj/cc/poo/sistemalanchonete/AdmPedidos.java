package br.unifaj.cc.poo.sistemalanchonete;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class AdmPedidos extends AppCompatActivity {

    private static final String URL_PEDIDOS = "http://10.0.2.2:8080/lanchonete/pedido";

    private List<String> listaPedidos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adm_pedidos);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        carregarPedidos();
    }

    private void carregarPedidos() {
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest req = new StringRequest(
                Request.Method.GET, URL_PEDIDOS,
                json -> {
                    try {
                        JSONArray array = (JSONArray) new JSONTokener(json).nextValue();
                        listaPedidos.clear();

                        for (int i = 0; i < array.length(); i++) {
                            JSONObject p = array.getJSONObject(i);

                            // monta o que o cliente pediu
                            String itens = "";

                            // lanches fixos
                            if (p.getInt("cheese")  > 0) itens += p.getInt("cheese")  + "x Cheese  ";
                            if (p.getInt("bacon")   > 0) itens += p.getInt("bacon")   + "x Bacon  ";
                            if (p.getInt("cheddar") > 0) itens += p.getInt("cheddar") + "x Cheddar  ";
                            if (p.getInt("xtudo")   > 0) itens += p.getInt("xtudo")   + "x X-Tudo  ";

                            // lanche customizado
                            if (p.has("ingredientesLanche") && !p.isNull("ingredientesLanche")) {
                                JSONArray ings = p.getJSONArray("ingredientesLanche");
                                if (ings.length() > 0) {
                                    itens += "| Faça seu lanche: ";
                                    for (int j = 0; j < ings.length(); j++) {
                                        itens += ings.getString(j) + " , ";
                                    }
                                }
                            }

                            String linha = "Pedido #" + p.getInt("id")
                                    + " — " + p.getString("nomeCliente")
                                    + "\n" + itens
                                    + "\nTotal: " + p.getString("total")
                                    + " | Status: " + p.getString("status");

                            listaPedidos.add(linha);
                        }

                        if (listaPedidos.isEmpty()) {
                            listaPedidos.add("Nenhum pedido no momento.");
                        }

                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                                android.R.layout.simple_list_item_1, listaPedidos);
                        ListView lv = findViewById(R.id.admPedidos_lista_lv);
                        lv.setAdapter(adapter);

                    } catch (Exception e) {
                        Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                erro -> Toast.makeText(this, "Servidor offline", Toast.LENGTH_SHORT).show()
        );
        queue.add(req);
    }

    public void marcarPronto(View v) {
        EditText idET = findViewById(R.id.adm_id_pedido_et);
        String idStr = idET.getText().toString().trim();

        if (idStr.isEmpty()) {
            Toast.makeText(this, "Digite o número do pedido", Toast.LENGTH_SHORT).show();
            return;
        }

        String url = "http://10.0.2.2:8080/lanchonete/pedido/" + idStr;

        try {
            JSONObject body = new JSONObject();
            body.put("status", "PRONTO");
            String json = body.toString();

            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest req = new StringRequest(
                    Request.Method.PUT, url,
                    resp -> {
                        Toast.makeText(this, "Pedido #" + idStr + " marcado como PRONTO", Toast.LENGTH_SHORT).show();
                        idET.setText("");
                        carregarPedidos();
                    },
                    erro -> Toast.makeText(this, "Pedido não encontrado", Toast.LENGTH_SHORT).show()
            ) {
                @Override public String getBodyContentType() { return "application/json; charset=utf-8"; }
                @Override public byte[] getBody() throws AuthFailureError { return json.getBytes(); }
            };
            queue.add(req);

        } catch (Exception e) {
            Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void voltar(View V) {
        finish();
    }
}
