package br.unifaj.cc.poo.sistemalanchonete;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

public class FacaSeuLanche extends AppCompatActivity {
    private static final String URL_ING    = "http://10.0.2.2:8080/lanchonete/ingrediente";
    private static final String URL_PEDIDO = "http://10.0.2.2:8080/lanchonete/pedido";

    //list do que vai ser selecionado
    private List<String> nomes = new ArrayList<>();
    private List<Integer> quantidades = new ArrayList<>();
    private List<Double> precos = new ArrayList<>();
    private List<Integer> selecionados = new ArrayList<>();
    private String nomeCliente;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_faca_seu_lanche);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        nomeCliente = getIntent().getStringExtra("nome");
        if (nomeCliente == null) nomeCliente = "Cliente";
        carregarIngredientes();
    }

    private void carregarIngredientes() {
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest req = new StringRequest(
                Request.Method.GET, URL_ING,
                json -> {
                    try {
                        JSONArray array = (JSONArray) new JSONTokener(json).nextValue();
                        nomes.clear();
                        quantidades.clear();
                        selecionados.clear();

                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);
                            nomes.add(obj.getString("nome"));
                            quantidades.add(obj.getInt("quantidade"));
                            precos.add(obj.getDouble("preco"));
                        }

                        if (nomes.isEmpty()) {
                            Toast.makeText(this, "Nenhum ingrediente disponível no estoque",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }

                        // Monta lista exibindo nome e quantidade
                        List<String> exibicao = new ArrayList<>();
                        for (int i = 0; i < nomes.size(); i++) {
                            exibicao.add(nomes.get(i) + "  (" + quantidades.get(i) + " disponíveis)" + "  Valor: " + precos.get(i).toString());
                        }

                        ListView lv = findViewById(R.id.faca_ingredientes_lv);
                        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                                android.R.layout.simple_list_item_multiple_choice, exibicao);
                        lv.setAdapter(adapter);

                        lv.setOnItemClickListener((parent, view, position, id) -> {
                            double total = 0;
                            for (int i = 0; i < nomes.size(); i++) {
                                if (lv.isItemChecked(i)) {
                                    total += precos.get(i);
                                }
                            }
                            TextView totalTV = findViewById(R.id.faca_total_tv);
                            totalTV.setText("Total: " + String.format("R$ %.2f", total));
                        });

                    } catch (Exception e) {
                        Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                },
                erro -> Toast.makeText(this, "Servidor offline", Toast.LENGTH_SHORT).show()
        );
        queue.add(req);
    }

    public void confirmarLanche(View v) {
        ListView lv = findViewById(R.id.faca_ingredientes_lv);
        double total = 0;
        List<String> escolhidos = new ArrayList<>();

        for (int i = 0; i < nomes.size(); i++) {
            if (lv.isItemChecked(i)) {
                if (quantidades.get(i) <= 0) {
                    Toast.makeText(this, nomes.get(i) + " está sem estoque!", Toast.LENGTH_SHORT).show();
                    return;
                }
                escolhidos.add(nomes.get(i));
                total += precos.get(i);
            }
        }

        if (escolhidos.isEmpty()) {
            Toast.makeText(this, "Selecione ao menos um ingrediente", Toast.LENGTH_SHORT).show();
            return;
        }

        // atualiza o TextView do total antes de enviar
        TextView totalTV = findViewById(R.id.faca_total_tv);
        totalTV.setText("Total: " + String.format("R$ %.2f", total));

        try {
            JSONObject pedido = new JSONObject();
            pedido.put("nomeCliente", nomeCliente);
            pedido.put("cheese", 0);
            pedido.put("bacon", 0);
            pedido.put("cheddar", 0);
            pedido.put("xtudo", 0);
            pedido.put("total", String.format("R$ %.2f", total));
            pedido.put("ingredientesLanche", new JSONArray(escolhidos));
            String json = pedido.toString();

            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest req = new StringRequest(
                    Request.Method.POST, URL_PEDIDO,
                    resp -> {
                        Toast.makeText(this, "Pedido enviado! " + String.join(", ", escolhidos), Toast.LENGTH_LONG).show();
                        finish();
                    },
                    erro -> Toast.makeText(this, "Erro ao enviar pedido", Toast.LENGTH_SHORT).show()
            ) {
                @Override public String getBodyContentType() { return "application/json; charset=utf-8"; }
                @Override public byte[] getBody() throws AuthFailureError { return json.getBytes(); }
            };
            queue.add(req);

        } catch (Exception e) {
            Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void voltar(View v) {
        finish();
    }
}
