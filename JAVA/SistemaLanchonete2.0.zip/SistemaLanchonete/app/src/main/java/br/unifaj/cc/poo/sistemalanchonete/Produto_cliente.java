package br.unifaj.cc.poo.sistemalanchonete;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Produto_cliente extends AppCompatActivity {
    private static final String URL_INGREDIENTE = "http://10.0.2.2:8080/lanchonete/ingrediente";
    private String nomeRecuperado;


    //lanches daqui ate
    static int quantidadeCheese = 0;
    static int quantidadeBacon = 0;
    static int quantidadeCheddar = 0;
    static int quantidadeXtudo = 0;
    //aqui

    //estoque daqui ate
    static int estoqueQueijo = 0;
    static int estoqueBacon = 0;
    static int estoqueCheddar = 0;
    static int estoqueCarne = 0;
    //aqui

    private int idQueijo  = -1;
    private int idBacon   = -1;
    private int idCheddar = -1;
    private int idCarne   = -1;

    //validaçao de quantos pode pedir
    static int carnecontadas = 0;
    static int baconcontados = 0;
    static int queijocontados = 0;
    static int cheddarcontados = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_produto_cliente);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Reset dos contadores
        quantidadeCheese = 0;
        quantidadeBacon = 0;
        quantidadeCheddar = 0;
        quantidadeXtudo = 0;
        carnecontadas = 0;
        baconcontados = 0;
        queijocontados = 0;
        cheddarcontados = 0;

        nomeRecuperado = getIntent().getStringExtra("nome");
        carregarEstoque();
        validar();
    }

    private void carregarEstoque() {
        RequestQueue queue = Volley.newRequestQueue(this);
        StringRequest req = new StringRequest(
                Request.Method.GET, URL_INGREDIENTE,
                json -> {
                    try {
                        JSONArray array = (JSONArray) new JSONTokener(json).nextValue();
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);
                            String nome = obj.getString("nome").trim().toLowerCase();
                            int qtd  = obj.getInt("quantidade");
                            int id   = obj.optInt("id", -1);

                            switch (nome) {
                                case "queijo":
                                    estoqueQueijo = qtd;
                                    idQueijo = id;
                                    break;
                                case "bacon":
                                    estoqueBacon = qtd;
                                    idBacon = id;
                                    break;
                                case "cheddar":
                                    estoqueCheddar = qtd;
                                    idCheddar = id;
                                    break;
                                case "carne":
                                    estoqueCarne = qtd;
                                    idCarne = id;
                                    break;
                            }
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "Erro ao carregar estoque: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    // Exibe mesmo se algum ingrediente não foi encontrado
                    mostrar();
                },
                erro -> {
                    Toast.makeText(this, "Servidor offline — estoque zerado", Toast.LENGTH_SHORT).show();
                    mostrar();
                }
        );
        queue.add(req);
    }
    public void pedido(View V) {

        if (quantidadeCheese == 0 && quantidadeBacon == 0 && quantidadeCheddar == 0 && quantidadeXtudo == 0) {
            Toast.makeText(this, "Nenhum produto selecionado", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            JSONObject pedido = new JSONObject();
            pedido.put("nomeCliente", nomeRecuperado);
            pedido.put("cheese",  quantidadeCheese);
            pedido.put("bacon",   quantidadeBacon);
            pedido.put("cheddar", quantidadeCheddar);
            pedido.put("xtudo",   quantidadeXtudo);
            pedido.put("ingredientesLanche", new JSONArray()); //passar ingredientes como vazio e nao null
            double totalpedido = quantidadeCheese * 15.99 + quantidadeBacon * 18.99 + quantidadeCheddar * 19.99 + quantidadeXtudo * 21.99;
            pedido.put("total", String.format("R$ %.2f", totalpedido));
            String json = pedido.toString();

            String url = "http://10.0.2.2:8080/lanchonete/pedido";

            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest req = new StringRequest(
                    Request.Method.POST,
                    url,
                    resp -> {
                        Toast.makeText(this, "Pedido enviado!", Toast.LENGTH_SHORT).show();
                    },
                    erro -> Toast.makeText(this, "Erro ao enviar pedido", Toast.LENGTH_SHORT).show()
            ) {
                @Override public String getBodyContentType() { return "application/json; charset=utf-8"; }
                @Override public byte[] getBody() throws AuthFailureError { return json.getBytes(); }
            };
            queue.add(req);

        } catch (Exception e) {
            Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        int carneUsada   = quantidadeCheese + quantidadeBacon + quantidadeCheddar + quantidadeXtudo;
        int queijoUsado  = quantidadeCheese + quantidadeXtudo;
        int baconUsado   = quantidadeBacon  + quantidadeXtudo;
        int cheddarUsado = quantidadeCheddar + quantidadeXtudo;

        darBaixaEstoque(idCarne,   estoqueCarne   - carneUsada,   "Carne");
        darBaixaEstoque(idQueijo,  estoqueQueijo  - queijoUsado,  "Queijo");
        darBaixaEstoque(idBacon,   estoqueBacon   - baconUsado,   "Bacon");
        darBaixaEstoque(idCheddar, estoqueCheddar - cheddarUsado, "Cheddar");

        // Atualiza o estoque local
        estoqueCarne   -= carneUsada;
        estoqueQueijo  -= queijoUsado;
        estoqueBacon   -= baconUsado;
        estoqueCheddar -= cheddarUsado;

        Intent i = new Intent(this, Tempo_Produto.class);
        startActivity(i);
    }

    private void darBaixaEstoque(int id, int novaQuantidade, String nomeIng) {
        if (id < 0 || novaQuantidade < 0)
            return;

        String url = URL_INGREDIENTE + "/" + id;
        try {
            JSONObject body = new JSONObject();
            body.put("quantidade", novaQuantidade);
            String json = body.toString();

            RequestQueue queue = Volley.newRequestQueue(this);
            StringRequest req = new StringRequest(
                    Request.Method.PUT, url,
                    resp -> {},
                    erro -> Toast.makeText(this, "Erro ao atualizar " + nomeIng, Toast.LENGTH_SHORT).show()
            ) {
                @Override public String getBodyContentType() { return "application/json; charset=utf-8"; }
                @Override public byte[] getBody() throws AuthFailureError { return json.getBytes(); }
            };
            queue.add(req);
        } catch (Exception e) {
            Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void adicionarCheese(View v){
        if(estoqueQueijo > 0 && estoqueCarne > 0){
            if(queijocontados < estoqueQueijo && carnecontadas < estoqueCarne){
                quantidadeCheese++;
                queijocontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairCheese(View v){
        if(quantidadeCheese > 0){
            quantidadeCheese--;
            carnecontadas--;
            queijocontados--;
        }
        mostrar();
    }
    public void adicionarBacon(View v){
        if(estoqueBacon > 0 && estoqueCarne > 0){
            if(baconcontados < estoqueBacon && carnecontadas < estoqueCarne){
                quantidadeBacon++;
                baconcontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairBacon(View v){
        if(quantidadeBacon > 0){
            quantidadeBacon--;
            carnecontadas--;
            baconcontados--;
        }
        mostrar();
    }
    public void adicionarCheddar(View v){
        if(estoqueCheddar > 0 && estoqueCarne >0){
            if(cheddarcontados < estoqueCheddar && carnecontadas < estoqueCarne){
                quantidadeCheddar++;
                cheddarcontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairCheddar(View v){
        if(quantidadeCheddar > 0){
            quantidadeCheddar--;
            carnecontadas--;
            cheddarcontados--;
        }
        mostrar();
    }
    public void adicionarXtudo(View v){
        if(estoqueBacon >0 && estoqueCheddar >0 && estoqueQueijo >0 && estoqueCarne >0){
            if(baconcontados < estoqueBacon && queijocontados < estoqueQueijo && cheddarcontados < estoqueCheddar && carnecontadas < estoqueCarne){
                quantidadeXtudo++;
                baconcontados++;
                cheddarcontados++;
                queijocontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairXtudo(View v){
        if(quantidadeXtudo > 0){
            quantidadeXtudo--;
            baconcontados--;
            cheddarcontados--;
            queijocontados--;
            carnecontadas--;
        }
        mostrar();
    }
    public void mostrar(){
        TextView xtudoV = findViewById(R.id.produto_xtudo_view);
        TextView cheeseV = findViewById(R.id.produto_cheese_view);
        TextView baconV = findViewById(R.id.produto_bacon_view);
        TextView cheddarV = findViewById(R.id.produto_cheddar_view);
        TextView totalV   = findViewById(R.id.produto_total_view);

        xtudoV.setText(String.valueOf(quantidadeXtudo));
        cheeseV.setText(String.valueOf(quantidadeCheese));
        baconV.setText(String.valueOf(quantidadeBacon));
        cheddarV.setText(String.valueOf(quantidadeCheddar));

        double total = quantidadeCheese  * 15.99 + quantidadeBacon   * 18.99 + quantidadeCheddar * 19.99 + quantidadeXtudo   * 21.99;
        totalV.setText(String.format("R$ %.2f", total));

        validar();
    }
    public void validar(){
        TextView cheeseV = findViewById(R.id.produto_disponivel_cheese_view);
        TextView baconV = findViewById(R.id.produto_disponivel_bacon_view);
        TextView cheddarV = findViewById(R.id.produto_disponivel_cheddar_view);
        TextView xtudoV = findViewById(R.id.produto_disponivel_xtudo_view);

        if (queijocontados >= estoqueQueijo || carnecontadas >= estoqueCarne || estoqueQueijo == 0 || estoqueCarne == 0) {
            cheeseV.setText("(indisponivel)");
        } else {
            cheeseV.setText("(disponivel)");
        }

        if (baconcontados >= estoqueBacon || carnecontadas >= estoqueCarne || estoqueBacon == 0 || estoqueCarne == 0) {
            baconV.setText("(indisponivel)");
        } else {
            baconV.setText("(disponivel)");
        }

        if (cheddarcontados >= estoqueCheddar || carnecontadas >= estoqueCarne || estoqueCheddar == 0 || estoqueCarne == 0) {
            cheddarV.setText("(indisponivel)");
        } else {
            cheddarV.setText("(disponivel)");
        }

        if (baconcontados >= estoqueBacon || queijocontados >= estoqueQueijo || cheddarcontados >= estoqueCheddar || carnecontadas >= estoqueCarne || estoqueBacon == 0 || estoqueQueijo == 0 || estoqueCheddar == 0 || estoqueCarne == 0) {
            xtudoV.setText("(indisponivel)");
        } else {
            xtudoV.setText("(disponivel)");
        }
    }

    public void voltar(View V){
        finish();
    }

    public void facaSeuLanche(View V){
        Intent i = new Intent(this, FacaSeuLanche.class);
        i.putExtra("nome", nomeRecuperado);
        startActivity(i);
    }
}