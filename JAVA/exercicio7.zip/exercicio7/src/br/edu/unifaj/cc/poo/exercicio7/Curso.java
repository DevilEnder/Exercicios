package br.edu.unifaj.cc.poo.exercicio7;

public class Curso {
    private String nome;
    private Disciplina d1;
    private Disciplina d2;

    public Curso() {
    }

    public Curso(String nome, Disciplina d1, Disciplina d2) {
        this.nome = nome;
        this.d1 = d1;
        this.d2 = d2;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Disciplina getD1() {
        return d1;
    }

    public void setD1(Disciplina d1) {
        this.d1 = d1;
    }

    public Disciplina getD2() {
        return d2;
    }

    public void setD2(Disciplina d2) {
        this.d2 = d2;
    }
}
