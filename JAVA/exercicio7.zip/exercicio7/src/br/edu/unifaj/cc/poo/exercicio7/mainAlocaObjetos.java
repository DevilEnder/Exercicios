package br.edu.unifaj.cc.poo.exercicio7;

public class mainAlocaObjetos {
    public static void main(String[] args) {
        Universidade univ = new Universidade();
        univ.setNome("UniFAJ");
        univ.setC1(new Curso());
        univ.setC2(new Curso());
        univ.getC1().setNome("Ciências da computação");
        univ.getC1().setD1((new Disciplina()));
        univ.getC1().setD2(new Disciplina());
        univ.getC1().getD1().setNome("Projeto integrado e prog orientada a objetos");
        univ.getC1().getD2().setNome("Prog Mobile e desenvolvimento web");
        Professor p1 = new Professor("Marco A. M.");
        univ.getC1().getD1().setP(p1);
        univ.getC1().getD2().setP(p1);

        univ.getC2().setNome("Controle e automação");
        univ.getC2().setD1(new Disciplina());
        univ.getC2().setD2(new Disciplina());
        univ.getC2().getD1().setNome("Calculo 1");
        univ.getC2().getD2().setNome("Automaçao 1");
        Professor p2 = new Professor("Alguem da automaçao");
        univ.getC2().getD1().setP(p2);
        univ.getC2().getD2().setP(p2);

        System.out.println("universidade: "+univ.getNome());
        System.out.println("Curso 1: "+univ.getC1().getNome());
        System.out.println("Disciplina 1: "+univ.getC1().getD1().getNome());
        System.out.println("Disciplina 2: "+univ.getC1().getD2().getNome());
        System.out.println("Prof. Disc 1: "+ univ.getC1().getD1().getP().getNome());

        System.out.println("");

        System.out.println("Curso 2: "+univ.getC2().getNome());
        System.out.println("Disciplina 1: "+univ.getC2().getD1().getNome());
        System.out.println("Disciplina 2: "+univ.getC2().getD2().getNome());
        System.out.println("Prof. Disc 2: "+univ.getC2().getD1().getP().getNome());
    }
}
