package br.edu.unifaj.cc.poo.exercicio7;

public class Universidade {
    private String nome;
    private Curso c1;
    private Curso c2;

    public Universidade() {
    }

    public Universidade(Curso c2, Curso c1, String nome) {
        this.c2 = c2;
        this.c1 = c1;
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Curso getC1() {
        return c1;
    }

    public void setC1(Curso c1) {
        this.c1 = c1;
    }

    public Curso getC2() {
        return c2;
    }

    public void setC2(Curso c2) {
        this.c2 = c2;
    }
}
