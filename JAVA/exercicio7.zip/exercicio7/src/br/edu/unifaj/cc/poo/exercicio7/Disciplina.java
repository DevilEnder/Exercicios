package br.edu.unifaj.cc.poo.exercicio7;

public class Disciplina {
    private String nome;
    private Professor p;

    public Disciplina() {
    }

    public Disciplina(String nome, Professor p) {
        this.nome = nome;
        this.p = p;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Professor getP() {
        return p;
    }

    public void setP(Professor p) {
        this.p = p;
    }
}
