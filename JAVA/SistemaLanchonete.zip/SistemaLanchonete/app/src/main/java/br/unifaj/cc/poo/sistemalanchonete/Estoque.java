package br.unifaj.cc.poo.sistemalanchonete;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Estoque extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_estoque);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void voltar(View V){
        finish();
    }

    public void salvarEstoque(View V){
        EditText queijo = findViewById(R.id.estoque_queijo_edittext);
        EditText bacon = findViewById(R.id.estoque_bacon_edittext);
        EditText cheddar = findViewById(R.id.estoque_cheddar_edittext);
        EditText carne = findViewById(R.id.estoque_carne_edittext);
        queijo.getText();
        bacon.getText();
        cheddar.getText();
        carne.getText();

       Produto_cliente.contadorqueijo = Integer.parseInt(queijo.getText().toString());
       Produto_cliente.contadorbacon = Integer.parseInt(bacon.getText().toString());
       Produto_cliente.contadorcheddar = Integer.parseInt(cheddar.getText().toString());
       Produto_cliente.contadorcarne = Integer.parseInt(carne.getText().toString());

        Toast.makeText(this, "Estoque Salvo com sucesso", Toast.LENGTH_SHORT).show();

    }
}