package br.unifaj.cc.poo.sistemalanchonete;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Produto_cliente extends AppCompatActivity {

    private String nomeRecuperado;
    //lanches daqui ate
    static int contadorCheese = 0;
    static int contadorBacon = 0;
    static int contadorCheddar = 0;
    static int contadorXtudo = 0;
    //aqui
    //estoque daqui ate
    static int contadorqueijo = 0;
    static int contadorbacon = 0;
    static int contadorcheddar = 0;
    static int contadorcarne = 0;
    //aqui
    //validaçao de quantos pode pedir
    static int carnecontadas = 0;
    static int baconcontados = 0;
    static int queijocontados = 0;
    static int cheddarcontados = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_produto_cliente);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Reset dos contadores
        contadorCheese = 0;
        contadorBacon = 0;
        contadorCheddar = 0;
        contadorXtudo = 0;
        carnecontadas = 0;
        baconcontados = 0;
        queijocontados = 0;
        cheddarcontados = 0;
        nomeRecuperado = getIntent().getStringExtra("nome");
        mostrar();
        validar();
    }

    public void pedido(View V){
        AdmPedidos.nomeCliente = nomeRecuperado;
        AdmPedidos.cheese = String.valueOf(contadorCheese);
        AdmPedidos.bacon = String.valueOf(contadorBacon);
        AdmPedidos.xtudo = String.valueOf(contadorXtudo);
        AdmPedidos.cheddar = String.valueOf(contadorCheddar);

        if(contadorCheese == 0 && contadorBacon == 0 && contadorCheddar == 0 && contadorXtudo == 0){
            Toast.makeText(this, "Nenhum produto selecionado", Toast.LENGTH_SHORT).show();
            return;
        }else{
            Intent i = new Intent(this, Tempo_Produto.class);
            startActivity(i);
        }

    }
    public void total(){
        TextView total = findViewById(R.id.produto_total_view);
        double totalpedido = contadorCheese*15.99 + contadorBacon*18.99 + contadorCheddar*19.99 + contadorXtudo*21.99;
        total.setText(String.format("R$ %.2f", totalpedido));
        AdmPedidos.total = String.format("R$ %.2f", totalpedido);
    }

    public void adicionarCheese(View v){
        if(contadorqueijo > 0 && contadorcarne > 0){
            if(queijocontados < contadorqueijo && carnecontadas < contadorcarne){
                contadorCheese++;
                queijocontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairCheese(View v){
        if(contadorCheese > 0){
            contadorCheese--;
            carnecontadas--;
            queijocontados--;
        }
        mostrar();
    }
    public void adicionarBacon(View v){
        if(contadorbacon > 0 && contadorcarne > 0){
            if(baconcontados < contadorbacon && carnecontadas < contadorcarne){
                contadorBacon++;
                baconcontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairBacon(View v){
        if(contadorBacon > 0){
            contadorBacon--;
            carnecontadas--;
            baconcontados--;
        }
        mostrar();
    }
    public void adicionarCheddar(View v){
        if(contadorcheddar > 0 && contadorcarne>0){
            if(cheddarcontados < contadorcheddar && carnecontadas < contadorcarne){
                contadorCheddar++;
                cheddarcontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairCheddar(View v){
        if(contadorCheddar > 0){
            contadorCheddar--;
            carnecontadas--;
            cheddarcontados--;
        }
        mostrar();
    }
    public void adicionarXtudo(View v){
        if(contadorbacon>0 && contadorcheddar>0 && contadorqueijo>0 && contadorcarne>0){
            if(baconcontados < contadorbacon && queijocontados < contadorqueijo && cheddarcontados < contadorcheddar && carnecontadas < contadorcarne){
                contadorXtudo++;
                baconcontados++;
                cheddarcontados++;
                queijocontados++;
                carnecontadas++;
            }
        }
        mostrar();
    }
    public void subtrairXtudo(View v){
        if(contadorXtudo > 0){
            contadorXtudo--;
            baconcontados--;
            cheddarcontados--;
            queijocontados--;
            carnecontadas--;
        }
        mostrar();
    }
    public void mostrar(){
        TextView xtudoV = findViewById(R.id.produto_xtudo_view);
        TextView cheeseV = findViewById(R.id.produto_cheese_view);
        TextView baconV = findViewById(R.id.produto_bacon_view);
        TextView cheddarV = findViewById(R.id.produto_cheddar_view);

        xtudoV.setText(String.valueOf(contadorXtudo));
        cheeseV.setText(String.valueOf(contadorCheese));
        baconV.setText(String.valueOf(contadorBacon));
        cheddarV.setText(String.valueOf(contadorCheddar));

        total();
    }

    public void validar(){
        TextView cheeseV = findViewById(R.id.produto_disponivel_cheese_view);
        TextView baconV = findViewById(R.id.produto_disponivel_bacon_view);
        TextView cheddarV = findViewById(R.id.produto_disponivel_cheddar_view);
        TextView xtudoV = findViewById(R.id.produto_disponivel_xtudo_view);

        if(contadorqueijo > 0 && contadorcarne > 0){
            cheeseV.setText("(disponivel)");
        }else{
            cheeseV.setText("(indisponivel)");
        }

        if(contadorbacon > 0 && contadorcarne > 0){
            baconV.setText("(disponivel)");
        }else{
            baconV.setText("(indisponivel)");
        }

        if(contadorcheddar > 0 && contadorcarne > 0){
            cheddarV.setText("(disponivel)");
        }else{
            cheddarV.setText("(indisponivel)");
        }

        if(contadorcarne > 0 &&  contadorbacon > 0 && contadorcheddar > 0 && contadorqueijo > 0){
            xtudoV.setText("(disponivel)");
        }else{
            xtudoV.setText("(indisponivel)");
        }
    }



    public void voltar(View V){
        finish();
    }
}