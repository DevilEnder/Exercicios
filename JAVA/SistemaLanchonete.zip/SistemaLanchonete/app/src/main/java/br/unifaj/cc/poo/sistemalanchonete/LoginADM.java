package br.unifaj.cc.poo.sistemalanchonete;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginADM extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_adm);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void sair(View V){
        finish();
    }
    public void login(View V){
        EditText nomeET = findViewById(R.id.login_nome_edittext);
        EditText senhaET = findViewById(R.id.login_senha_edittext);

        if(nomeET.getText().toString().equals("adm") && senhaET.getText().toString().equals("123456")){
            Toast.makeText(this, "Login Bem Sucedido", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, EscolhaADM.class);
            startActivity(i);
        }else{
            Toast.makeText(this, "Login Inválido", Toast.LENGTH_SHORT).show();
        }

    }
}