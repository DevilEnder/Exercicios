package br.unifaj.cc.poo.sistemalanchonete;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

public class AdmPedidos extends AppCompatActivity {

    public static String nomeCliente;
    public static String cheese;
    public static String bacon;
    public static String xtudo;
    public static String cheddar;
    public static String total;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adm_pedidos);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        TextView nomeView = findViewById(R.id.admPedidos_cliente_view);
        TextView cheeseView = findViewById(R.id.admPedidos_cheese_view);
        TextView baconView = findViewById(R.id.admPedidos_bacon_view);
        TextView xtudoView = findViewById(R.id.admPedidos_xtudo_view);
        TextView cheddarView = findViewById(R.id.admPedidos_cheddar_view);
        TextView totalView = findViewById(R.id.admpedido_total_view);


        if (nomeCliente != null) {
            nomeView.setText(nomeCliente);
        }

        if(cheese != null){
            if(cheese.equals("0")){
                cheeseView.setText("");
            }
            else{
                cheeseView.setText(cheese + "x  Cheese burguer");
            }
        }

        if(bacon != null){
            if(bacon.equals("0")){
                baconView.setText("");
            }
            else{
                baconView.setText(bacon + "x  Bacon burguer");
            }
        }

        if(cheddar != null){
            if(cheddar.equals("0")){
                cheddarView.setText("");
            }
            else{
                cheddarView.setText(cheddar + "x  Cheddar burguer");
            }
        }

        if(xtudo != null){
            if(xtudo.equals("0")){
                xtudoView.setText("");
            }
            else{
                xtudoView.setText(xtudo + "x  X-Tudo");
            }
        }

        if(total != null){
            totalView.setText(total);
        }
    }

    public void voltar(View V){
        finish();
    }
}