package br.unifaj.cc.poo.sistemalanchonete;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Cliente extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cliente);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void concluir(View V){
        EditText nomeET = findViewById(R.id.cliente_nome_edittext);
        EditText telefoneET = findViewById(R.id.cliente_telefone_edittext);
        String telefone = telefoneET.getText().toString();
        String nome = nomeET.getText().toString();

        if(nome.isEmpty()){
            Toast.makeText(this, "Digite um nome", Toast.LENGTH_SHORT).show();
            return;
        }
        if(nome.isBlank()){
            Toast.makeText(this, "Digite um nome", Toast.LENGTH_SHORT).show();
            return;
        }
        if(nome.length() < 3){
            Toast.makeText(this, "Digite um nome válido", Toast.LENGTH_SHORT).show();
            return;
        }
        if(nome.length() > 40){
            Toast.makeText(this, "Digite um nome válido", Toast.LENGTH_SHORT).show();
            return;
        }

        if(telefone.isEmpty()){
            Toast.makeText(this, "Digite um telefone", Toast.LENGTH_SHORT).show();
            return;
        }
        if(telefone.length() != 11){
            Toast.makeText(this, "Digite um telefone válido", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Cadastro realizado com sucesso", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this,Produto_cliente.class);
        i.putExtra("nome", nome);
        startActivity(i);
    }
    public void fechar(View V){
        finish();
    }
}