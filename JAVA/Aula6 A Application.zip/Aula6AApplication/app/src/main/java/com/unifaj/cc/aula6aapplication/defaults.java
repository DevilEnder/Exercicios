package com.unifaj.cc.aula6aapplication;

public class defaults {
    public static final String arquivo = "Aula6";
    public static final String usuario = "usuario";
    public static final String senha = "senha";

}
