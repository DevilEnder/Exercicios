package com.unifaj.cc.aula6aapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        carregar();
    }// fim oncreate

    public void carregar() {
        SharedPreferences sp = getSharedPreferences(defaults.arquivo, Context.MODE_PRIVATE);
        String usuario = sp.getString(defaults.usuario, "");
        String senha = sp.getString(defaults.senha, "");

        TextView usuarioTV = findViewById(R.id.View_usuario_textview);
        TextView senhaTV = findViewById(R.id.View_senha_textview);

        usuarioTV.setText("usuario: "+ usuario);
        senhaTV.setText("senha: "+senha);

    }

}// fim classe