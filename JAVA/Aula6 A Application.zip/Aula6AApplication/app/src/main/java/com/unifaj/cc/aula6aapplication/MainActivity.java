package com.unifaj.cc.aula6aapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        carregar();
    }// fim oncreate

    public void sair(View V){
        finish();
    }

    public void salvar (View V){
        EditText usuarioET = findViewById(R.id.main_usuario_edittext);
        EditText senhaET = findViewById(R.id.main_senha_edittext);

        String usuario = usuarioET.getText().toString();
        String senha = senhaET.getText().toString();

        SharedPreferences sp = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(defaults.usuario, usuario);
        editor.putString(defaults.senha, senha);
        editor.commit();
    }

    public void exibirActivity(View V){
        salvar(V);

        Intent i = new Intent(this, ViewActivity.class);
        startActivity(i);

    }

    public void carregar(){
        SharedPreferences sp = getSharedPreferences(defaults.arquivo,Context.MODE_PRIVATE);
        String usuario = sp.getString(defaults.usuario, "");
        String senha = sp.getString(defaults.senha, "");

        EditText usuarioET = findViewById(R.id.main_usuario_edittext);
        EditText senhaET = findViewById(R.id.main_senha_edittext);
        usuarioET.setText(usuario);
        senhaET.setText(senha);
    }


}//fim da classe