package br.edu.unifaj.cc.poo.aula7;

import java.sql.SQLOutput;
import java.util.*;

public class UtilizaCarrosMap {
    public static void main(String[] args) {
        Map<String , Carro> carros = new TreeMap<>();
        carros.put("PPX-1234", new Carro("PPX-1234", "Preto", "Maria"));
        carros.put("PPX-1234", new Carro("PPX-1234", "Preto", "Maria"));
        carros.put("ABC-1235", new Carro("ABC-1235", "Branco", "José"));
        carros.put("BCD-2345", new Carro("BCD-2345", "Azul", "Pedro"));
        carros.put("CDE-3456", new Carro("CDE-3456", "Vermelho", "João"));

        //Collections.sort(carros);
        //Percorre todos os valores
        System.out.println("Todos os Valores");
        for(Carro carro : carros.values()) {
            System.out.println(carro);
        }

        //Percorrer todas as chaves set
        System.out.println("____________________________");
        System.out.println("Todas as Chaves");
        for(String chave : carros.keySet()){
            System.out.println(chave);
        }

        System.out.println("______________________________");
        System.out.println("Informe uma Placa: ");
        Scanner sc = new Scanner(System.in);
        String placa = sc.nextLine();
        Carro carro = carros.get(placa); // motivo da existencia do map, passa a placa e ele retorna o objeto, rapidamente.
        if (carro != null){
            System.out.println(carro);
        }else {
            System.out.println("Carro não encontrado");
        }
    }


}
