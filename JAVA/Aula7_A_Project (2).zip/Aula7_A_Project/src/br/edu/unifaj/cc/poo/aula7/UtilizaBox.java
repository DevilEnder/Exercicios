package br.edu.unifaj.cc.poo.aula7;

public class UtilizaBox {
    public static void main(String[] args) {
        Box<Integer> box1 = new Box();
        box1.put(10);
        Box<String> box2 = new Box();
        box2.put("Maria");

        // Utilizar os valores
        Integer v1 = box1.get();
        String v2 = box2.get();
        System.out.println(v1 + " " + v2);
    }
}
