package br.edu.unifaj.cc.poo.aula7;

public class Box <T>{
    private T obj;

    public void put(T obj){
        this.obj = obj;
    }

    public T get(){
        return this.obj;
    }
}
