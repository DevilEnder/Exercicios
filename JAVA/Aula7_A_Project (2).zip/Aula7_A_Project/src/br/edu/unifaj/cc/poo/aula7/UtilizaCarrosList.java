package br.edu.unifaj.cc.poo.aula7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UtilizaCarrosList {
    public static void main(String[] args) {
        List<Carro> carros = new ArrayList<>();
        carros.add(new Carro("PPX-1234", "Preto", "Maria"));
        carros.add(new Carro("PPX-1234", "Preto", "Maria"));
        carros.add(new Carro("ABC-1235", "Branco", "José"));
        carros.add(new Carro("BCD-2345", "Azul", "Pedro"));
        carros.add(new Carro("CDE-3456", "Vermelho", "João"));

        Collections.sort(carros);

        for(Carro carro : carros) {
            System.out.println(carro);
        }
    }


}
