package br.edu.unifaj.cc.poo.aula7;

import java.util.*;

public class UtilizaCarrosSet {
    public static void main(String[] args) {
        Set<Carro> carros = new TreeSet<>();
        carros.add(new Carro("PPX-1234", "Preto", "Maria"));
        carros.add(new Carro("PPX-1234", "Preto", "Maria"));
        carros.add(new Carro("ABC-1235", "Branco", "José"));
        carros.add(new Carro("BCD-2345", "Azul", "Pedro"));
        carros.add(new Carro("CDE-3456", "Vermelho", "João"));

        //Collections.sort(carros);

        for(Carro carro : carros) {
            System.out.println(carro);
        }
    }


}
