package br.edu.unifaj.cc.poo.aula7;

import java.util.*;

public class EntraNomeLista {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite nomes.  Enter duplo para encerrar");
        //List<String> nomes = new ArrayList<>();
        List<String> nomes = new LinkedList<>();
        while (true) {
            String nome = sc.nextLine();
            if (nome == null || nome.equals("")) {
                break;
            }
            nomes.add(nome);
        }
        //Ordenar a Lista
        Collections.sort(nomes);

        // Percorrer a Lista
        for (int i = 0; i < nomes.size(); i++) {
            //Recupera a posição
            System.out.println("Nome" + (i + 1)
                    + ":" + nomes.get(i));  //Clássico get(i)
        }
    }
}
