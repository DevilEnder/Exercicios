package br.edu.unifaj.cc.poo.aula7;

import java.util.*;

public class EntraNomesSet {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite nomes.  Enter duplo para encerrar");
        //List<String> nomes = new ArrayList<>();
        Set<String> nomes = new TreeSet<>();
        while (true) {
            String nome = sc.nextLine();
            if (nome == null || nome.equals("")) {
                break;
            }
            nomes.add(nome);
        }
        //Não é possível ordenar o SET
        //Collections.sort(nomes);

        // Percorrer o SET
        for (String nome : nomes) {
            System.out.println("Nome" + ":" + nome);  //Não tem posição
        }
    }
}
