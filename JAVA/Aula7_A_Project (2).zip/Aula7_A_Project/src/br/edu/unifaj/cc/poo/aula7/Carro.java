package br.edu.unifaj.cc.poo.aula7;

public class Carro implements Comparable<Carro> {
    String placa;
    String cor;
    String dono;

    public Carro(String placa, String cor, String dono) {
        this.placa = placa;
        this.cor = cor;
        this.dono = dono;
    }



    @Override
    public String toString() {
        return "Carro{" +
                "placa='" + placa +
                ", cor='" + cor +
                ", dono='" + dono +
                '}';
    }

    @Override
    public int compareTo(Carro o) {
        int ret = this.placa.compareTo(o.placa);
        if (ret == 0) {
            ret = this.cor.compareTo(o.cor);
            if (ret == 0) {
                ret = this.dono.compareTo(o.dono);
            }
        }
        return ret;
    }

    @Override
    public int hashCode() {
        return this.placa.hashCode();
    }

}
