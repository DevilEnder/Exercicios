package br.edu.unifaj.cc.poo.aula7;

public class MainTesteTipoObjeto {

    public static void main(String[] args) {
        try {
            Number num = (Number) validar(100);
            System.out.println(num);

            String str = (String) validar("Tiradentes");
            System.out.println(str);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Object validar(Object obj) throws Exception {
        if (obj instanceof Number) {
            Number num = (Number) obj;
            if (num.floatValue() > 10) {
                return num;
            }
        }

        if (obj instanceof String) {
            String str = (String) obj;
            if (str.equalsIgnoreCase("Tiradentes")) {
                return "Bom feriado";
            }
            return obj;
        }

        throw new Exception("Objeto inválido");
    }

}
