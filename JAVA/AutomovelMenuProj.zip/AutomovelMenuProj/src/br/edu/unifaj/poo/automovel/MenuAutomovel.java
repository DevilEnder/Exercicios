package br.edu.unifaj.poo.automovel;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MenuAutomovel {
    static void main() {
       MenuAutomovel obj = new MenuAutomovel();
       obj.menu();
       System.out.println("Fim do menu de automóvel");
    }

    static int contador = 1;
    List<Automovel> lista = new ArrayList<>();

    public void menu(){
        System.out.println("Iniciando o menu de automóvel");
        Scanner sc = new Scanner(System.in);

        while(true) {
            System.out.println("1 -- Listar");
            System.out.println("2 -- Incluir");
            System.out.println("3 -- Excluir");
            System.out.println("4 -- Sair");
            System.out.print("Digite a opção: ");
            int opcao = sc.nextInt();
            sc.nextLine();// consome o final da linha

            switch (opcao) {
                case 1:
                    listar();
                    break;
                case 2:
                    incluir(sc);
                    break;
                case 3:
                    excluir(sc);
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Opção invalida: " + opcao);
            }
        }

    }// fim void menu

    private void sair() {
    }

    private void excluir(Scanner sc) {
        System.out.println("Excluir automovel");
        System.out.print("Digite a placa do carro: ");
        String placa = sc.nextLine();


        for(int i=0; i<lista.size(); i++){
            Automovel a = lista.get(i);
            if(a.placa.equals(placa)){
                lista.remove(i);
                System.out.println("Automovel excluido com sucesso!");
                return;
            }
        }
        System.out.println("Placa nao encontrada na lista");
    }

    private void incluir(Scanner sc) {
        System.out.println("Incluir automovel");
        System.out.print("Placa: ");
        String placa = sc.nextLine();

        System.out.print("numPortas: ");
        int numPortas = sc.nextInt();
        sc.nextLine();

        System.out.print("Combustivel: ");
        String combustivel = sc.nextLine();

        System.out.print("Modelo: ");
        String modelo = sc.nextLine();

        //criar o objetvo automovel
        Automovel automovel = new Automovel(contador++,placa, numPortas,combustivel,modelo);
        lista.add(automovel);
    }

    private void listar() {
        for (int i = 0; i<lista.size(); i++){ // ele sugere isso: for (Automovel a : lista) {
            Automovel a = lista.get(i);
            System.out.println("Automovel id:"+a.id+ " Placa:"+ a.placa + " numPortas:"+ a.numPortas + " Combustivel:"+ a.combustivel + " Modelo:"  + a.modelo);
        }
    }
}// fim da classe menuautomovel
