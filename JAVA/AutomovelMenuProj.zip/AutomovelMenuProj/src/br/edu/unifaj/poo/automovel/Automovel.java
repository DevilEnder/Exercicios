package br.edu.unifaj.poo.automovel;

public class Automovel {
    int id;
    String placa;
    int numPortas;
    String combustivel;
    String modelo;

    public Automovel(int id, String placa, int numPortas, String combustivel, String modelo){
        this.id = id;
        this.placa = placa;
        this.numPortas = numPortas;
        this.combustivel = combustivel;
        this.modelo = modelo;
    }
}
