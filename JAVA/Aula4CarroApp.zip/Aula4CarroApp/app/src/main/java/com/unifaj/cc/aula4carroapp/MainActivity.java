package com.unifaj.cc.aula4carroapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static ArrayList <String> carros = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void incluir(View V){
        EditText etplaca = findViewById(R.id.main_edittext_placa);
        EditText etmodelo = findViewById(R.id.main_edittext_modelo);
        EditText etano = findViewById(R.id.main_edittext_ano);
        String placa = etplaca.getText().toString().trim();
        String modelo = etmodelo.getText().toString().trim();
        String ano = etano.getText().toString().trim();

        Spinner spinner = findViewById(R.id.main_spinner_cor);
        Spinner spinner2 = findViewById(R.id.main_spinner_estado);
        String cor = spinner.getSelectedItem().toString();
        String estado = spinner2.getSelectedItem().toString();

        if(placa.isEmpty() || modelo.isEmpty() || ano.isEmpty()){
            Toast.makeText(this,"preencha todos os campos", Toast.LENGTH_LONG).show();
            return;
        }

        String infoCarro = placa + " -- " + modelo + " -- " + ano + " -- " + cor + " -- " + estado;

        carros.add(infoCarro);
        Toast.makeText(this,"carro incluido com sucesso",Toast.LENGTH_LONG).show();
    }
    public void listview(View V){
        Intent i = new Intent(this, ListViewActivity.class);
        startActivity(i);
    }

}