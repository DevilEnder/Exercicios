package com.unifaj.cc.aula4carroapp;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ListViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        ListView listView = findViewById(R.id.listView);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_checked,
                MainActivity.carros);

        listView.setAdapter(adapter);
        listView.setChoiceMode(listView.CHOICE_MODE_MULTIPLE);
    }
        public void excluir(View V){
            ListView listview = findViewById(R.id.listView);
            SparseBooleanArray selecionados = listview.getCheckedItemPositions();
            if(selecionados == null || selecionados.size() == 0){
                Toast.makeText(this,"nao ha elementos selecionados", Toast.LENGTH_LONG).show();
                return;
            }
            for(int i = 0; i < selecionados.size(); i++){
                int pos = selecionados.keyAt(i);
                ArrayAdapter aa = (ArrayAdapter) listview.getAdapter();
                String valor = listview.getItemAtPosition(pos).toString();
                aa.remove(valor);
                Toast.makeText(this,"excluido com sucesso",Toast.LENGTH_LONG).show();
                break;
            }
        }
        public void voltar(View V){
        finish();
        }
}//fim do listview

