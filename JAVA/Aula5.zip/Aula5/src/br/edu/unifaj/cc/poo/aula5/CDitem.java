package br.edu.unifaj.cc.poo.aula5;

import java.util.Date;

public class CDitem extends itemBase{
    private String cantor;
    private int numTrilhas;

    public CDitem() {
    }

    public CDitem(Integer id, String nome, String observacao, String estado, Date anoLancamento, String cantor, int numTrilhas) {
        super(id, nome, observacao, estado, anoLancamento);
        this.cantor = cantor;
        this.numTrilhas = numTrilhas;
    }

    public String getCantor() {
        return cantor;
    }

    public void setCantor(String cantor) {
        this.cantor = cantor;
    }

    public int getNumTrilhas() {
        return numTrilhas;
    }

    public void setNumTrilhas(int numTrilhas) {
        this.numTrilhas = numTrilhas;
    }
}
