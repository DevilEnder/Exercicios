package br.edu.unifaj.cc.poo.aula5.FormaPagamento;

public class UtilizaFormaPagamento {
    public static void main(String[] args) {
        FormaPagamento f1 = new Dinheiro();
        f1.valor = 100.0f;
        print(f1);

        FormaPagamento f2 = new Cartao();
        f2.valor = 200.0f;
        print(f2);
    }
    public static void print(FormaPagamento fp){
        System.out.println(fp.getClass().getName() + "Valor: "+ fp.valor + "Pode Parcelar: "+fp.podeParcelar()+ "Valor da parcela 10x: "+ fp.calcularParcelas(10));
    }
}
