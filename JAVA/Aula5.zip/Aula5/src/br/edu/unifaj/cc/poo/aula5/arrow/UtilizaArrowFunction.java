package br.edu.unifaj.cc.poo.aula5.arrow;

public class UtilizaArrowFunction {

    public static class ExecuteToUpper implements Execute {

        @Override
        public String execute(String str) {
            return str.toUpperCase();
        }
    }

    public static void main(String[] args) {
        //objetode uma classe que implementa a interface
        String str = testExecute(new ExecuteToUpper());
        //innerclass da interface execute
        String str1 = testExecute(new Execute() {
            @Override
            public String execute(String str) {
                return str.toUpperCase();
            }
        });
        //arrow function
        String str2 = testExecute(s -> s.toUpperCase());

    }
    public static String testExecute(Execute ex){
        return ex.execute("joao");
    }
}
