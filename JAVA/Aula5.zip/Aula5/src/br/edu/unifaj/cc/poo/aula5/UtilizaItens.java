package br.edu.unifaj.cc.poo.aula5;

import java.util.Date;

public class UtilizaItens {
    public static void main(String[] args) {
        DVDitem dvd = new DVDitem(1,"One Night Only", "Show do Bee Gees","Perdido",new Date(1999, 1, 1 ),"Berry Bee");

    }
}
