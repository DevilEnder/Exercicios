package br.edu.unifaj.cc.poo.aula5.crud;

import java.util.ArrayList;
import java.util.List;

public class PessoaCrud implements Crud{

    private List<Entity> list = new ArrayList<>();

    private long lastId = 1;

    @Override
    public Entity create(Entity e) {
        e.setId((lastId++));
        list.add(e);
        return e;
    }

    @Override
    public Entity find(Long id) {
        for(Entity e : list){
            if (e.getId() == id){
                return e;
            }
        }
        return null;
    }

    @Override
    public List<Entity> findAll() {
        return list;
    }

    @Override
    public Entity update(Entity e) {
        for(int i = 0; i < list.size(); i++){
            Entity temp = list.get(i);
            if(temp.getId() == e.getId()){
                list.set(i, e);
            }
        }
        return null;
    }

    @Override
    public void delete(Long id) {
        for(int i = 0; i < list.size(); i++){
            if(list.get(i).getId() == id){
                list.remove(i);
                return ;
            }
        }
    }
}
