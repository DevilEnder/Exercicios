package br.edu.unifaj.cc.poo.aula5;

import java.util.Date;

public class Livroitem extends itemBase {
    private String escritor;

    public Livroitem() {
    }

    public Livroitem(Integer id, String nome, String observacao, String estado, Date anoLancamento, String escritor) {
        super(id, nome, observacao, estado, anoLancamento);
        this.escritor = escritor;
    }

    public String getEscritor() {
        return escritor;
    }

    public void setEscritor(String escritor) {
        this.escritor = escritor;
    }
}
