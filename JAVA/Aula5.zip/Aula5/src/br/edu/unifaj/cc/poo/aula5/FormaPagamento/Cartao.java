package br.edu.unifaj.cc.poo.aula5.FormaPagamento;

public class Cartao extends FormaPagamento {
    @Override
    public boolean podeParcelar() {
        return true;
    }

    @Override
    public float calcularParcelas(int parcela) {
        return valor / parcela * 0.1f;
    }
}
