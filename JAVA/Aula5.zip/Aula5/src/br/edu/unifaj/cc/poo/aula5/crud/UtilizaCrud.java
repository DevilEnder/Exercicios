package br.edu.unifaj.cc.poo.aula5.crud;

import java.util.List;

public class UtilizaCrud {

    public static void main(String[] args) {
        Crud crud = new PessoaCrud();

        Pessoa p = new Pessoa();
        p.setNome("Maria");
        p.setCpf("222.333.444-11");
        crud.create(p);

        Pessoa p2 = new Pessoa();
        p2.setNome("Josefo");
        p2.setCpf("412.421.543-67");
        crud.create(p2);

        List<Entity> list = crud.findAll();
        for(Entity e : list){
            Pessoa p3 = (Pessoa) e; //type cast
            System.out.println("Pessoa: "
                    +"Id: "+p3.getId()
                    +" Nome: "+ p3.getNome()
                    +" CPF: "+ p3.getCpf());
        }
    }

}
