package br.edu.unifaj.cc.poo.aula5.crud;

import java.util.List;

public interface Crud {
    Entity create(Entity e);
    Entity find(Long id);
    List<Entity> findAll();
    Entity update(Entity e);
    void delete(Long id);
}
