package br.edu.unifaj.cc.poo.aula5.FormaPagamento;

public class FormaPagamento {
    public float valor;

    public boolean podeParcelar() {
        return false;
    }

    public float calcularParcelas(int parcela) {
        return valor;
    }
}
