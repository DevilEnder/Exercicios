package br.edu.unifaj.cc.poo.aula5.FormaPagamento;

public class Dinheiro extends FormaPagamento{


}
