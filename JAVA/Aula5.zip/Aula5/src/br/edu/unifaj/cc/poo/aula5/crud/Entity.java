package br.edu.unifaj.cc.poo.aula5.crud;

public interface Entity {
    void setId (Long id);
    Long getId();
}
