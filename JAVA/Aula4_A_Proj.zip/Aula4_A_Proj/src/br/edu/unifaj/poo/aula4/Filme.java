package br.edu.unifaj.poo.aula4;

public class Filme {
    private String titulo;

    public Filme() {
    }

    public Filme(String titulo) {
        this.titulo = titulo;
    }

    public void ligar() {
        System.out.println("Filme " + titulo + "ligado");
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}

