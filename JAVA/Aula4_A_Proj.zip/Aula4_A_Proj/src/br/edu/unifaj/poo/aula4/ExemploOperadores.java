package br.edu.unifaj.poo.aula4;

import java.util.Scanner;

public class ExemploOperadores {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digita 2 strings");
        String str1 = sc.nextLine();
        String str2 = sc.nextLine();

        //Forma errada
        if (str1 == str2) {
            System.out.println("== STR são iguais");
        } else {
            System.out.println("== STR não iguais");
        }


        if (str1.equals(str2)) {
            System.out.println("Equals STR são iguais");
        } else {
            System.out.println("=Equals STR não iguais");
        }
    }
}
