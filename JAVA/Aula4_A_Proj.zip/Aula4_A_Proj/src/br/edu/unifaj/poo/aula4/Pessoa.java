package br.edu.unifaj.poo.aula4;

public class Pessoa {
    protected String nome;
    private int idade;
    private String telefone;

    public Pessoa(String nome, int idade, String telefone) {
        this.nome = nome;
        this.idade = idade;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void andar() {
        System.out.println("Pessoa " + this.nome + " andando");
    }

    public void assistirTv() {
        System.out.println("Pessoa " + this.nome + " assistindo TV");
    }
}
