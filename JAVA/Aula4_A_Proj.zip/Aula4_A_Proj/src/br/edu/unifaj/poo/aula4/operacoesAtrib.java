package br.edu.unifaj.poo.aula4;

public class operacoesAtrib{
    private float a;
    private float b;
    private float c;

    public operacoesAtrib(float a, float b, float c){
        this.a = a;
        this.b = b;
        this.c = c;
    }
    float somar(){
        return a+b+c;
    }
    float maior(){
        float max = a;
        if(b > max){
            max = b;
        }
        if(c > max){
            max = c;
        }
        return max;
    }
}
