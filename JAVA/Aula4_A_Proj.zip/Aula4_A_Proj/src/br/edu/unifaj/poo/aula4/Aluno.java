package br.edu.unifaj.poo.aula4;

public class Aluno extends Pessoa {
    private int ra;
    private float notas[] = {0,0,0,0};  //new float[4]

    public Aluno(String nome, int idade, String telefone, int ra, float[] notas) {
        super(nome, idade, telefone);
        this.ra = ra;
        this.notas = notas;
    }

    public int getRa() {
        return ra;
    }

    public void setRa(int ra) {
        this.ra = ra;
    }

    public float[] getNotas() {
        return notas;
    }

    public void setNotas(float[] notas) {
        this.notas = notas;
    }

    public void estudar() {
        System.out.println("Aluno " + this.getNome() + " estudando");
    }

    public float calcularMedia() {
        //Calcular se o Aluno passou
        float soma = 0;
        for (int i = 0; i < this.notas.length; i++) {
            soma += this.notas[i];
        }
        float nota = soma / this.notas.length;
        return nota;
    }

    public void verificarSePasou() {
        float nota = calcularMedia();
        if (nota >= 6) {
            System.out.println("A aluna:" + this.nome
                    + " passou.");
        } else {
            System.out.println("A aluna:" + this.nome
                    + " ficou de sub.");
        }
    }
}
