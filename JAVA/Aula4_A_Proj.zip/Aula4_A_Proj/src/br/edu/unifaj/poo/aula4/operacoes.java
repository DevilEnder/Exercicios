package br.edu.unifaj.poo.aula4;

public class operacoes {

    public float soma(float a, float b, float c) {
        float total = a+b+c;
        return total;
    }
    public int maior(int a, int b, int c) {
        int max = a;
        if (b > max){
            max = b;
        }
        if (c > max){
            max = c;
        }
        return max;
    }
}
