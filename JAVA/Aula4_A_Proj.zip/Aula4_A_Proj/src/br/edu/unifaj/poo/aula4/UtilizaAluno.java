package br.edu.unifaj.poo.aula4;

public class UtilizaAluno {
    public static void main(String[] args) {
        float[] notas = {2, 6, 7, 10};
        Aluno a1 = new Aluno("Maria", 16, "2233445", 1234, notas);
        a1.estudar();
        a1.verificarSePasou();
    }
}
