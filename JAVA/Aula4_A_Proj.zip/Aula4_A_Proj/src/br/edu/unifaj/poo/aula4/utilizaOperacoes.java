package br.edu.unifaj.poo.aula4;

public class utilizaOperacoes {
    public static void main(String[] args) {
        operacoes op = new operacoes();
        float soma = op.soma(1.0f, 2.0f, 3.0f);
        System.out.println("Soma: " + soma);

        int maior = op.maior(5,10,20);
        System.out.println("Maior: " + maior);



        operacoesAtrib op2 = new operacoesAtrib(1.0f, 2.0f, 3.0f);
        soma = op2.somar();
        System.out.println("Soma: " + soma);
        maior = (int) op2.maior();
        System.out.println("Maior: " + maior);
    }
}
