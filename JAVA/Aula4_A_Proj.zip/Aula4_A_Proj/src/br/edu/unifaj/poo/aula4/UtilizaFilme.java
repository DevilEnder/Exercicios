package br.edu.unifaj.poo.aula4;

public class UtilizaFilme {

    public static void main(String[] args) {

        Filme f1 = null;
        f1 = new Filme("senhor dos anais");

        Filme f2 = f1;
        f2.ligar();

        Filme f3 = null;
        f3.ligar();
    }
}
