package br.edu.unifaj.poo.maquiagem;

public class Main {
    public static void main(String[] args) {
        MenuMaquiagem obj = new MenuMaquiagem();
        obj.menu();
    }
}
