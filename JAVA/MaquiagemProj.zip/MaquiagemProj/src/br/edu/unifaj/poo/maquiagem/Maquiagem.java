package br.edu.unifaj.poo.maquiagem;

public class Maquiagem {
    int id;
    String marca;
    double preco;
    String tipo;
    String cor;
    boolean provaDAqua;

    public Maquiagem(int id, String marca, double preco, String tipo, String cor, boolean provaDAqua){
        this.id = id;
        this.marca = marca;
        this.preco = preco;
        this.tipo = tipo;
        this.cor = cor;
        this.provaDAqua = provaDAqua;
    }
}
