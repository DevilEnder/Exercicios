package br.edu.unifaj.poo.maquiagem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MenuMaquiagem {
    static void main() {
       MenuMaquiagem obj = new MenuMaquiagem();
       obj.menu();
       System.out.println("Fim do menu de Maquiagem");
    }

    static int contador = 1;
    List<Maquiagem> lista = new ArrayList<>();

    public void menu(){
        System.out.println("Iniciando o menu de maquiagem");
        Scanner sc = new Scanner(System.in);

        while(true) {
            System.out.println("1 -- Listar");
            System.out.println("2 -- Incluir");
            System.out.println("3 -- Excluir");
            System.out.println("4 -- Exibir Aluno");
            System.out.println("5 -- Sair");
            System.out.print("Digite a opcao: ");
            int opcao = sc.nextInt();
            sc.nextLine(); // consome o final da linha

            switch (opcao) {
                case 1:
                    listar();
                    break;
                case 2:
                    incluir(sc);
                    break;
                case 3:
                    excluir(sc);
                    break;
                case 4:
                    exibirAluno();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Opcao invalida: " + opcao);
            }
        }

    }// fim void menu

    private void exibirAluno() {
        System.out.println("Nome do aluno: Joao gabriel brandao");
        System.out.println("RA: 12529615");
    }

    private void excluir(Scanner sc) {
        System.out.println("Excluir maquiagem");
        System.out.print("Digite o id da maquiagem: ");
        int id = sc.nextInt();
        sc.nextLine();

        for(int i=0; i<lista.size(); i++){
            Maquiagem a = lista.get(i);
            if(a.id == id){
                lista.remove(i);
                System.out.println("Maquiagem excluida com sucesso!");
                return;
            }
        }
        System.out.println("Id nao encontrado na lista");
    }

    private void incluir(Scanner sc) {
        System.out.println("Incluir maquiagem");
        System.out.print("Marca: ");
        String marca = sc.nextLine();

        System.out.print("Preco: ");
        double preco = sc.nextDouble();
        sc.nextLine();

        System.out.print("Tipo: ");
        String tipo = sc.nextLine();

        System.out.print("Cor: ");
        String cor = sc.nextLine();

        System.out.print("Prova d'agua? (s/n): ");
        String resposta = sc.nextLine();
        boolean provaDAqua = resposta.equalsIgnoreCase("s");

        Maquiagem maquiagem = new Maquiagem(contador++, marca, preco, tipo, cor, provaDAqua);
        lista.add(maquiagem);
        System.out.println("Maquiagem incluida com sucesso! ID: " + maquiagem.id);
    }

    private void listar() {
        if(lista.isEmpty()){
            System.out.println("Nenhuma maquiagem cadastrada.");
            return;
        }
        for (int i = 0; i < lista.size(); i++){ // sinal amarelo para substituir por, for (Maquiagem a : lista) {
            Maquiagem a = lista.get(i);
            System.out.println("Maquiagem id:" + a.id + " Marca:" + a.marca + " Preco:" + a.preco + " Tipo:" + a.tipo + " Cor:" + a.cor + " Prova d'agua:" + (a.provaDAqua ? "Sim" : "Nao"));
        }
    }
}// fim da classe MenuMaquiagem
