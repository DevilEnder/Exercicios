package br.edu.unifaj.cc.mobile.aula4exemplosaapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.snackbar.Snackbar;

public class SnackbarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_snackbar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }  // Fim do OnCreate


    public void snackbarSimples(View v) {
        Snackbar.make(findViewById(R.id.main),
                        "Exemplo de Snackbar simples",
                        Snackbar.LENGTH_LONG)
                .show();
    }

    public void snackbarAction(View v) {
        EditText nomeET = findViewById(R.id.snack_nome_editText);
        String nome = nomeET.getText().toString();
        String mensagem = "O nome digitado foi " + nome;

        Snackbar.make(findViewById(R.id.main), mensagem, Snackbar.LENGTH_LONG)
                .setAction("Apagar nome", j -> limparTexto())
                .show();
    }

    public void limparTexto() {
        EditText nomeET = findViewById(R.id.snack_nome_editText);
        nomeET.setText("");
    }

}  //Fim da classe