package br.edu.unifaj.cc.mobile.aula4exemplosaapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class SpinnerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_spinner);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        preencherAnimais();
    } //Fim do OnCreate


    public void preencherAnimais() {
        List<String> list = new ArrayList<>();
        list.add("Cachorro");
        list.add("Gato");
        list.add("Coelho");
        list.add("Calopsita");
        list.add("Camundongo");

        ArrayAdapter<String> aa = new ArrayAdapter<>(
                this,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                list);
        Spinner spinner = findViewById(R.id.spinner_animais);
        spinner.setAdapter(aa);
    }

    public void exibirAutomovel(View v) {
        // 1 Recuperar o Componente Spinner
        // 2 Recuperar o único item selecionado
        // 3 Exibir o valor em um Toast
        Spinner spinner = findViewById(R.id.spinner_automovel);
        String automovel = spinner.getSelectedItem().toString();

        Toast.makeText(this, "Automovel:" + automovel,
                Toast.LENGTH_LONG).show();
    }

}  //Fim da Classe