package br.edu.unifaj.cc.mobile.aula4exemplosaapplication;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class ListViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_list_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        preencherListView();
    }//fim do oncreate

    public void preencherListView(){
        ArrayList list = new ArrayList();
        list.add("Pickup");
        list.add("carro");
        list.add("moto");
        list.add("triciclo");
        list.add("SUV");

        ArrayAdapter<String> aa = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_checked, list);

        ListView listview = findViewById(R.id.automoveis_listview);
        listview.setAdapter(aa);
        listview.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);


    }//fim do preencherlistview
    public void verificarSelecionados(View V){
        ListView listview = findViewById(R.id.automoveis_listview);
        SparseBooleanArray selecionados = listview.getCheckedItemPositions();
        if(selecionados == null || selecionados.size() == 0){
            Toast.makeText(this,"nao ha elementos selecionados", Toast.LENGTH_LONG).show();
            return;
        }
        String str = "selecionados: ";
        for(int i = 0; i < selecionados.size(); i++){
            int pos = selecionados.keyAt(i);
            String valor = listview.getItemAtPosition(pos).toString();
            str += valor + " ";
        }
        Toast.makeText(this, str, Toast.LENGTH_LONG).show();
    }

}//fim do listview