package br.com.unifaj.exercio.miquelino;

public class Exercicio218 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.18 | RA: 12529615 | Joao Gabriel Brandao");

        // Figura 1: Retangulo
        System.out.println("*********");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*       *");
        System.out.println("*********");

        System.out.println();

        // Figura 2: Elipse
        System.out.println("  ***  ");
        System.out.println(" *   * ");
        System.out.println("*     *");
        System.out.println("*     *");
        System.out.println("*     *");
        System.out.println("*     *");
        System.out.println("*     *");
        System.out.println(" *   * ");
        System.out.println("  ***  ");

        System.out.println();

        // Figura 3: Seta apontando para cima
        System.out.println("    *    ");
        System.out.println("   ***   ");
        System.out.println("  *****  ");
        System.out.println("    *    ");
        System.out.println("    *    ");
        System.out.println("    *    ");
        System.out.println("    *    ");
        System.out.println("    *    ");
        System.out.println("    *    ");

        System.out.println();

        // Figura 4: Losango
        System.out.println("    *    ");
        System.out.println("   * *   ");
        System.out.println("  *   *  ");
        System.out.println(" *     * ");
        System.out.println("  *   *  ");
        System.out.println("   * *   ");
        System.out.println("    *    ");
    }
}
