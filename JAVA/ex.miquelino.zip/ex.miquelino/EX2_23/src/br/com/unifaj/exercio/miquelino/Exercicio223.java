package br.com.unifaj.exercio.miquelino;

public class Exercicio223 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.23 | RA: 12529615 | Joao Gabriel Brandao");

        // Triangulo usando printf com especificadores de formato
        System.out.printf("%s%n%s%n%s%n", "*", "***", "*****");
    }
}
