package br.com.unifaj.exercio.miquelino;

import java.util.Scanner;

public class Exercicio224 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.24 | RA: 12529615 | Joao Gabriel Brandao");

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite o primeiro numero inteiro: ");
        int n1 = entrada.nextInt();
        System.out.print("Digite o segundo numero inteiro: ");
        int n2 = entrada.nextInt();
        System.out.print("Digite o terceiro numero inteiro: ");
        int n3 = entrada.nextInt();
        System.out.print("Digite o quarto numero inteiro: ");
        int n4 = entrada.nextInt();
        System.out.print("Digite o quinto numero inteiro: ");
        int n5 = entrada.nextInt();

        int maior = n1;
        if (n2 > maior) maior = n2;
        if (n3 > maior) maior = n3;
        if (n4 > maior) maior = n4;
        if (n5 > maior) maior = n5;

        int menor = n1;
        if (n2 < menor) menor = n2;
        if (n3 < menor) menor = n3;
        if (n4 < menor) menor = n4;
        if (n5 < menor) menor = n5;

        System.out.printf("Maior: %d%n", maior);
        System.out.printf("Menor: %d%n", menor);

        entrada.close();
    }
}
