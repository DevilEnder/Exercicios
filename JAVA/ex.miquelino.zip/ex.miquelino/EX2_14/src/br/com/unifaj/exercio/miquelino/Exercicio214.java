package br.com.unifaj.exercio.miquelino;

public class Exercicio214 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.14 | RA: 12529615 | Joao Gabriel Brandao");

        // a) Usando uma unica instrucao System.out.println
        System.out.println("1 2 3 4");

        // b) Usando quatro instrucoes System.out.print separadas
        System.out.print("1 ");
        System.out.print("2 ");
        System.out.print("3 ");
        System.out.print("4");
        System.out.println();

        // c) Usando uma unica instrucao System.out.printf
        System.out.printf("%d %d %d %d%n", 1, 2, 3, 4);
    }
}
