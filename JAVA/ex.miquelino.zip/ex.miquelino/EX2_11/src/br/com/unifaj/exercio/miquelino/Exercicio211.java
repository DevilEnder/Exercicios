package br.com.unifaj.exercio.miquelino;

public class Exercicio211 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.11 | RA: 12529615 | Joao Gabriel Brandao");
        int i = 1, j = 2, k = 3, p;
        p = i + j + k + 7;
        System.out.println("a) p = i + j + k + 7 -> p = " + p + " (a variavel p foi alterada)");
        System.out.println("b) System.out.println nao altera nenhuma variavel");
        System.out.println("c) System.out.println nao altera nenhuma variavel");
        System.out.println("d) valor = entrada.nextInt() altera a variavel valor");
    }
}
