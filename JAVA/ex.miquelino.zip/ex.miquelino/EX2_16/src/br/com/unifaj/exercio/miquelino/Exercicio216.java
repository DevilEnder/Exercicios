package br.com.unifaj.exercio.miquelino;

import java.util.Scanner;

public class Exercicio216 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.16 | RA: 12529615 | Joao Gabriel Brandao");

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite o primeiro numero inteiro: ");
        int a = entrada.nextInt();

        System.out.print("Digite o segundo numero inteiro: ");
        int b = entrada.nextInt();

        if (a > b)
            System.out.printf("%d eh o maior%n", a);

        if (b > a)
            System.out.printf("%d eh o maior%n", b);

        if (a == b)
            System.out.println("Os numeros sao iguais");

        entrada.close();
    }
}
