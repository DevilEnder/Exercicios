package br.com.unifaj.exercio.miquelino;

public class Exercicio219 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.19 | RA: 12529615 | Joao Gabriel Brandao");

        // Triangulo crescente usando printf
        System.out.printf("*%n**%n***%n****%n*****%n");
    }
}
