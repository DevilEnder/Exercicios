package br.com.unifaj.exercio.miquelino;

public class Exercicio222 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.22 | RA: 12529615 | Joao Gabriel Brandao");

        // Figura misturando print e println
        System.out.print("*");
        System.out.println("***");
        System.out.println("*****");
        System.out.print("****");
        System.out.println("**");
    }
}
