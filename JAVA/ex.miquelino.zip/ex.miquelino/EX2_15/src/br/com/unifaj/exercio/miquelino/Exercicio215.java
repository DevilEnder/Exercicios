package br.com.unifaj.exercio.miquelino;

import java.util.Scanner;

public class Exercicio215 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.15 | RA: 12529615 | Joao Gabriel Brandao");

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite o primeiro numero inteiro: ");
        int a = entrada.nextInt();

        System.out.print("Digite o segundo numero inteiro: ");
        int b = entrada.nextInt();

        System.out.printf("Soma: %d%n", a + b);
        System.out.printf("Produto: %d%n", a * b);
        System.out.printf("Diferenca: %d%n", a - b);
        System.out.printf("Quociente: %d%n", a / b);

        entrada.close();
    }
}
