package br.com.unifaj.exercio.miquelino;

public class Exercicio213 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.13 | RA: 12529615 | Joao Gabriel Brandao");

        int x;

        x = 7 + 3 * 6 / 2 - 1;
        System.out.println("a) x = 7 + 3 * 6 / 2 - 1 -> x = " + x);

        x = 2 % 2 + 2 * 2 - 2 / 2;
        System.out.println("b) x = 2 % 2 + 2 * 2 - 2 / 2 -> x = " + x);

        x = (3 * 9 * (3 + (9 * 3 / (3))));
        System.out.println("c) x = (3 * 9 * (3 + (9 * 3 / (3)))) -> x = " + x);
    }
}
