package br.com.unifaj.exercio.miquelino;

import java.util.Scanner;

public class Exercicio225 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.25 | RA: 12529615 | Joao Gabriel Brandao");

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite um numero inteiro: ");
        int n = entrada.nextInt();

        if (n % 2 == 0)
            System.out.printf("%d eh par%n", n);

        if (n % 2 != 0)
            System.out.printf("%d eh impar%n", n);

        entrada.close();
    }
}
