package br.com.unifaj.exercio.miquelino;

import java.util.Scanner;

public class Exercicio226 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.26 | RA: 12529615 | Joao Gabriel Brandao");

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite o primeiro numero inteiro: ");
        int a = entrada.nextInt();

        System.out.print("Digite o segundo numero inteiro: ");
        int b = entrada.nextInt();

        if (a % b == 0)
            System.out.printf("%d eh multiplo de %d%n", a, b);

        if (a % b != 0)
            System.out.printf("%d nao eh multiplo de %d%n", a, b);

        entrada.close();
    }
}
