package br.com.unifaj.exercio.miquelino;

public class Exercicio221 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.21 | RA: 12529615 | Joao Gabriel Brandao");

        // Figura usando print - todos na mesma linha
        System.out.print("*");
        System.out.print("***");
        System.out.print("*****");
        System.out.print("****");
        System.out.println("**");
    }
}
