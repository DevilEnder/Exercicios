package br.com.unifaj.exercio.miquelino;

public class Exercicio210 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.10 | RA: 12529615 | Joao Gabriel Brandao");

        int x = 2;
        int y = 3;

        // a)
        System.out.printf("x = %d%n", x);
        // b)
        System.out.printf("Valor de %d + %d eh %d%n", x, x, (x + x));
        // c)
        System.out.printf("x =");
        System.out.println();
        // d)
        System.out.printf("%d = %d%n", (x + y), (y + x));
    }
}
