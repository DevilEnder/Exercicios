package br.com.unifaj.exercio.miquelino;

public class Exercicio220 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.20 | RA: 12529615 | Joao Gabriel Brandao");

        // Figura usando println - cada linha separada
        System.out.println("*");
        System.out.println("***");
        System.out.println("*****");
        System.out.println("****");
        System.out.println("**");
    }
}
