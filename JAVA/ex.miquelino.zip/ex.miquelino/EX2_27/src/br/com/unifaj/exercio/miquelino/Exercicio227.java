package br.com.unifaj.exercio.miquelino;

public class Exercicio227 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.27 | RA: 12529615 | Joao Gabriel Brandao");

        // Tabuleiro de damas 8x8 com asteriscos alternados
        System.out.println("* * * * * * * *");
        System.out.println(" * * * * * * * *");
        System.out.println("* * * * * * * *");
        System.out.println(" * * * * * * * *");
        System.out.println("* * * * * * * *");
        System.out.println(" * * * * * * * *");
        System.out.println("* * * * * * * *");
        System.out.println(" * * * * * * * *");
    }
}
