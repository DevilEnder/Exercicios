package br.com.unifaj.exercio.miquelino;

import java.util.Scanner;

public class Exercicio217 {
    public static void main(String[] args) {
        System.out.println("Exercicio 2.17 | RA: 12529615 | Joao Gabriel Brandao");

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite o primeiro numero inteiro: ");
        int a = entrada.nextInt();

        System.out.print("Digite o segundo numero inteiro: ");
        int b = entrada.nextInt();

        System.out.print("Digite o terceiro numero inteiro: ");
        int c = entrada.nextInt();

        int soma = a + b + c;
        int media = soma / 3;
        int produto = a * b * c;

        int menor = a;
        if (b < menor) menor = b;
        if (c < menor) menor = c;

        int maior = a;
        if (b > maior) maior = b;
        if (c > maior) maior = c;

        System.out.printf("Soma: %d%n", soma);
        System.out.printf("Media: %d%n", media);
        System.out.printf("Produto: %d%n", produto);
        System.out.printf("Menor valor: %d%n", menor);
        System.out.printf("Maior valor: %d%n", maior);

        entrada.close();
    }
}
