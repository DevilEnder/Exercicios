import java.util.Scanner;

public class exemplotry {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("digite o valor a ser divido: ");
            int num = sc.nextInt();sc.nextLine();
            System.out.println("digite o valor a dividir: ");
            int valor = sc.nextInt();sc.nextLine();
            float result = num / valor;
            System.out.println(" o resultado da divisão é" + result);
        } catch (Exception ex) {
            System.out.println("ocorreu um erro" + ex.getMessage());
            //ex.printStackTrace();
        } finally {
            System.out.println("programa encerrado");

        }
    }
}
