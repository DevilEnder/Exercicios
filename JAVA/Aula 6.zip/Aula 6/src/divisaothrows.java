import java.util.Scanner;

public class divisaothrows {
    public static void main(String[] args) throws Exception {
            Scanner sc = new Scanner(System.in);
            System.out.println("digite o valor a ser divido: ");
            int num = sc.nextInt();sc.nextLine();
            System.out.println("digite o valor a dividir: ");
            int valor = sc.nextInt();sc.nextLine();

            float resultado = divisao(num, valor);
            System.out.println(" o resultado da divisão é" + resultado);

    }

    public static float divisao (int num, int div)
        throws aula6exception{

            if ( div == 0 ){
                throw new aula6exception("divisor zerado");
            }
            float resultado = (float) num / div;
            return resultado;
        }
    }

