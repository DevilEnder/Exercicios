import java.util.Scanner;

public class vetordeobjeto {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int x;
        System.out.print("quantos usuarios voce quer ter? : \n");
        x = Integer.parseInt(sc.nextLine());
        String[] nomes = new String [x];
        for (int i = 0; i < nomes.length; i++){
            System.out.print("digite o "+ (i+1) +" nome: ");
            nomes[i] = sc.nextLine();
        }
        System.out.println("pressione enter para listar");
        sc.nextLine();
        for(int i = 0; i < nomes.length; i++){
            if(i < nomes.length - 1) {
                System.out.print(nomes[i] + ", ");
            }
            else {
                System.out.println(nomes[i]);
            }
        }
        System.out.println("fim do programa.");
    }
}
