public class aula6exception extends RuntimeException {
    public aula6exception(String message) {
        super(message);
    }
}
