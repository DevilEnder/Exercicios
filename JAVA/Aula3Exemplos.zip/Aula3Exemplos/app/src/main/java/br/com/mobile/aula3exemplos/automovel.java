package br.com.mobile.aula3exemplos;

public class automovel {
}
