package br.com.mobile.aula3exemplos;

public class utilizarautomovel {

    public static void main(String[] args) {
        automovel a1 = new Automovel();
        a1.placa = "QGC 1968";
        a1.numportas = 4;

        automovel a2 = new Automovel();
        a2.placa = "bcd 1183";
        a2.numportas = 2;

        System.out.println("Automovel 1: "+a1);
        System.out.println("Automovel 2: "+a2);

    }
}
