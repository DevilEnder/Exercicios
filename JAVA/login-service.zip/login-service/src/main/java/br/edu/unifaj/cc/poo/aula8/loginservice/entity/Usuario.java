package br.edu.unifaj.cc.poo.aula8.loginservice.entity;

import lombok.Data;

@Data
public class Usuario {
    private Long id;
    private String usuario;
    private String senhaMd5;
}
