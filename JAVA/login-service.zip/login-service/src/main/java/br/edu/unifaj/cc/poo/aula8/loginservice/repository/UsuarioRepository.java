package br.edu.unifaj.cc.poo.aula8.loginservice.repository;

import br.edu.unifaj.cc.poo.aula8.loginservice.entity.Usuario;
import br.edu.unifaj.cc.poo.aula8.loginservice.service.UsuarioService;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.TreeMap;

@Repository
public class UsuarioRepository {

    static private long nextId = 1;

    private Map<Long, Usuario> usuarios = new TreeMap<>();

    public UsuarioRepository(){
        Usuario u1 = new Usuario();
        u1.setId(nextId++);
        u1.setUsuario("maria");
        u1.setSenhaMd5(UsuarioService.converterParaMD5("123456"));

        Usuario u2 = new Usuario();
        u2.setId(nextId++);
        u2.setUsuario("isabella");
        u2.setSenhaMd5(UsuarioService.converterParaMD5("654321"));

        usuarios.put(u1.getId(), u1);
        usuarios.put(u2.getId(), u2);
    }

    public Usuario inserir(Usuario usuario){
        usuario.setId((nextId++));
        usuarios.put(usuario.getId(), usuario);
        return usuario;
    }

    public Usuario buscarPorUsuario(String usuario){
        for(Usuario u: usuarios.values()){
            if(u.getUsuario().equals(usuario)){
                return u;
            }
        }
        return null;
    }
}
