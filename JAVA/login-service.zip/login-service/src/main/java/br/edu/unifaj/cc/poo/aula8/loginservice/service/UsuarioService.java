package br.edu.unifaj.cc.poo.aula8.loginservice.service;

import br.edu.unifaj.cc.poo.aula8.loginservice.dto.UsuarioRequestDto;
import br.edu.unifaj.cc.poo.aula8.loginservice.dto.UsuarioResponseDto;
import br.edu.unifaj.cc.poo.aula8.loginservice.entity.Usuario;
import br.edu.unifaj.cc.poo.aula8.loginservice.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.security.MessageDigest;

@Service
public class UsuarioService {

    @Autowired UsuarioRepository repository;

    public UsuarioResponseDto login(UsuarioRequestDto request) {
        UsuarioResponseDto response = new UsuarioResponseDto();
        Usuario u = repository.buscarPorUsuario(request.getUsuario());
        if (u == null) {
            response.setStatus("NOK");
            response.setError("Usuário não cadastrado");
            return response;
        }
        String senhaMd5 = converterParaMD5(request.getSenha());
        if (!(u.getSenhaMd5().equals(senhaMd5))) {
            response.setStatus("NOK");
            response.setError("Senha inválida");
            return response;
        }
        response.setStatus("OK");
        response.setToken("Token " + u.getId());
        return response;
    }

    public static String converterParaMD5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            BigInteger no = new BigInteger(1, messageDigest);

            // Converte o valor numérico para a representação hexadecimal
            String hashtext = no.toString(16);

            // Garante que o hash tenha 32 caracteres (preenche com zeros à esquerda se necessário)
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao gerar MD5", e);
        }
    }
}
