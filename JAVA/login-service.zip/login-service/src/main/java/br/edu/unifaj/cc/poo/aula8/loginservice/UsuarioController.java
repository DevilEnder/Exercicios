package br.edu.unifaj.cc.poo.aula8.loginservice;

import br.edu.unifaj.cc.poo.aula8.loginservice.dto.UsuarioRequestDto;
import br.edu.unifaj.cc.poo.aula8.loginservice.dto.UsuarioResponseDto;
import br.edu.unifaj.cc.poo.aula8.loginservice.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class UsuarioController {

    @Autowired UsuarioService service;

    @PostMapping("/login")
    public UsuarioResponseDto login(@RequestBody UsuarioRequestDto request){
        return service.login(request);
    }
}
