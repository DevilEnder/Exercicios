package br.edu.unifaj.cc.poo.aula8.loginservice.dto;

import lombok.Data;

@Data
public class UsuarioResponseDto {
    private String status; //OK ou Nok, logo um boolean
    private String error; //Mensagem de erro
    private String token; //Deveria ser um JWT(java web token) mas nao vai ser
}
