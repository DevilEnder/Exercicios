package br.edu.unifaj.cc.poo.aula8.loginservice.dto;

import lombok.Data;

@Data
public class UsuarioRequestDto {
    private String usuario;
    private String senha;

}
