package br.edu.unifaj.cc.poo.aula8service;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Servico {
    private Integer id;
    private String nome;
    private String descr;
    private float valor;
}