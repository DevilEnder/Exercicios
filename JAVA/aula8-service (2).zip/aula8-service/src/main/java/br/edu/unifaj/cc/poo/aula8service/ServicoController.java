package br.edu.unifaj.cc.poo.aula8service;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ServicoController {

    private Map<Integer, Servico> servicoMap = new HashMap();

    public ServicoController() {
        Servico s1 = new Servico(1, "Café", "Café expresso", 6.0f);
        Servico s2 = new Servico(2, "Pingado", "Café com leite", 10f);
        servicoMap.put(s1.getId(), s1);
        servicoMap.put(s2.getId(), s2);
    }
    @GetMapping("/servico")
    public List<Servico> getServicos(){
        return new ArrayList<>(servicoMap.values());
    }

    @GetMapping("/servico/{id}")
    public Servico getServico(@PathVariable Integer id){
        return servicoMap.get(id);
    }

    //Só funciona com Formulario (Form)
    @PostMapping("/servicoForm")
    public Servico postServicoForm(Servico servico){
        return servicoMap.put(servico.getId(), servico);
    }

    //Enviar JSON
    @PostMapping("/servico")
    public Servico postServico(@RequestBody Servico servico){
        return servicoMap.put(servico.getId(), servico);
    }

    @DeleteMapping("servico/{id}")
     public void deleteServico(@PathVariable Integer id){
        servicoMap.remove(id);
    }
}