package br.edu.unifaj.mobile.aula3aloginapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        exibirdados();
    }// fim do oncreate

    public void exibirdados(){
        Intent intent= getIntent();
        String usuario = intent.getStringExtra("usuario");
        String senha = intent.getStringExtra("senha");

        TextView usuarioTV = findViewById(R.id.Data_usuario_textview);
        TextView senhaTV = findViewById(R.id.Data_senha_textview);

        usuarioTV.setText(usuario);
        senhaTV.setText(senha);

    }

    public void fechar(View V){
        finish();
    }

} //fim da classe