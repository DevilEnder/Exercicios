package br.edu.unifaj.mobile.aula3aloginapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button okButton = findViewById(R.id.main_ok_button);
//        okButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                okButtonClick(null);
//            }
//        });
       // okButton.setOnClickListener(i -> okButtonClick(null));


    } //Fim do metodo onCreate

    public void okButtonClick(View v) {
        EditText usuarioET = findViewById(R.id.main_user_editText);
        EditText senhaET = findViewById(R.id.main_password_editText);

        String usuario = usuarioET.getText().toString();
        String senha = senhaET.getText().toString();

        if (usuario == null || usuario.trim().isEmpty()) {
            Toast.makeText(this, "usuario nao pode ser vazio", Toast.LENGTH_SHORT).show();

            return;
        }

        if (senha == null || senha.trim().isEmpty()){
            Toast.makeText(this, "senha obrigatoria",Toast.LENGTH_LONG).show();

            return;
        }

        Intent intent = new Intent(this,DataActivity.class);
        intent.putExtra("usuario", usuario);
        intent.putExtra("senha", senha);
        startActivity(intent);


    }

    public void cancelButtonClick(View v) {
        finish();  //Fecha a atividade.  Se a última, fecha a aplicação
    }

}  //Fim da Classe