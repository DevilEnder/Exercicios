package br.unifaj.cc.as.aula3loginapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_idade_textview), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    public void logar(View V){
        EditText usuario = findViewById(R.id.main_usuario_edittext);
        EditText senha = findViewById(R.id.main_senha_edittext);

        if(usuario.getText().toString().equals("aluno") && senha.getText().toString().equals("123456")){
            Toast.makeText(this, "Bem Vindo Aluno", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this,LoginAprovado.class);
            startActivity(i);
        }else{
            Toast.makeText(this, "Login invalido", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this,login_reprovado.class);
            startActivity(i);
        }

    }

    public void sair(View V){
        finish();
    }
}